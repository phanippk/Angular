angular.module("config", [])
.constant("BUCKET_SLUG", "d95fa870-d75f-11e8-9661-272fca804673")
.constant("MEDIA_URL", "https://api.cosmicjs.com/v1/undefined/media")
.constant("URL", "https://api.cosmicjs.com/v1/")
.constant("READ_KEY", "nGUQkzPfIVuJfPQT1ZxOHhRd4ZliKgCwRHvMMil1qdoiJ1qqI8")
.constant("WRITE_KEY", "8O5Td5hzqYkCiYlzkUdWwOjOYypTvGoX380g5Ojo8iYuwqrUDl")
.constant("STRIPE_KEY", "");
